#pragma once

namespace argumentViewer{
  class ArgumentViewer;
  class ArgumentViewerImpl;
  namespace ex{
    class Exception;
    class MatchError;
  }
}
